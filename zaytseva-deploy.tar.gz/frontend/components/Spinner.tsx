export function Spinner() {
  return <span className="spinner" aria-label="Загрузка" />;
}
