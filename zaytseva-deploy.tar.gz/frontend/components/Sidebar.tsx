"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon, IconName } from "@/components/Icon";
import { useAuth } from "@/lib/auth";
import { getInitial } from "@/lib/format";

const links: Array<{ href: string; label: string; icon: IconName }> = [
  { href: "/dashboard", label: "Главная", icon: "dashboard" },
  { href: "/projects", label: "Проекты", icon: "projects" },
  { href: "/waiting", label: "Жду", icon: "waiting" },
  { href: "/payments", label: "Деньги", icon: "money" },
  { href: "/calendar", label: "Календарь", icon: "calendar" },
  { href: "/tasks", label: "Задачи", icon: "tasks" },
];

export function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  return <aside className="sidebar">
    <Link href="/dashboard" className="brand"><span className="brand__mark">ZI</span><span><strong>Zaytseva</strong><small>INTERIOR WORKSPACE</small></span></Link>
    <nav className="sidebar__nav">
      {links.map((link) => {
        const active = pathname === link.href || (link.href !== "/dashboard" && pathname.startsWith(`${link.href}/`));
        return <Link key={link.href} href={link.href} className={`nav-link ${active ? "nav-link--active" : ""}`}><Icon name={link.icon} size={18}/><span>{link.label}</span></Link>;
      })}
    </nav>
    <button type="button" className="profile-card" onClick={logout}>
      <span className="avatar">{getInitial(user?.name || "Z")}</span>
      <span className="profile-card__text"><strong>{user?.name}</strong><small>{user?.role === "owner" ? "Руководитель студии" : "Дизайнер / комплектатор"}</small></span>
      <Icon name="logout" size={18}/>
    </button>
  </aside>;
}
