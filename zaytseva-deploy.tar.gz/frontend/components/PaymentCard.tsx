"use client";
import { useState } from "react";
import { PaymentStatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { formatDate, formatMoney, paymentKindLabels } from "@/lib/format";
import { Payment, PaymentStatus } from "@/lib/types";

export function PaymentCard({ item, projectName, procurementName, onUpdated }: { item: Payment; projectName?: string; procurementName?: string; onUpdated: (item: Payment) => void }) {
  const { token } = useAuth(); const [busy, setBusy] = useState(false); const [error, setError] = useState("");
  async function change(status: PaymentStatus) { if (!token) return; setBusy(true); setError(""); try { onUpdated(await api.changePaymentStatus(token, item.id, status)); } catch (e) { setError(e instanceof Error ? e.message : "Не удалось изменить статус оплаты"); } finally { setBusy(false); } }
  return <article className={`payment-card ${item.is_overdue ? "payment-card--overdue" : ""}`}><div className="payment-card__top"><div>{projectName ? <span className="eyebrow">{projectName}</span> : null}<h3>{item.title}</h3><small>{paymentKindLabels[item.kind]}</small></div><PaymentStatusBadge status={item.status} overdue={item.is_overdue}/></div><strong className="payment-card__amount">{formatMoney(item.amount, item.currency)}</strong><div className="payment-card__meta"><span>Контрагент: {item.counterparty || "Не указан"}</span><span>Срок: {formatDate(item.due_date)}</span>{procurementName ? <span>Позиция: {procurementName}</span> : null}</div>{item.notes ? <p>{item.notes}</p> : null}{error ? <div className="inline-error">{error}</div> : null}<div className="button-row button-row--compact">{item.status === "pending" ? <><button type="button" className="button button--primary button--small" disabled={busy} onClick={() => change("paid")}>Отметить оплаченным</button><button type="button" className="button button--ghost button--small" disabled={busy} onClick={() => change("cancelled")}>Отменить</button></> : <button type="button" className="button button--secondary button--small" disabled={busy} onClick={() => change("pending")}>Вернуть в ожидание</button>}</div></article>;
}
