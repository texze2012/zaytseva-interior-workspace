"use client";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { EmptyState } from "@/components/EmptyState";
import { Icon } from "@/components/Icon";
import { PageHeader } from "@/components/PageHeader";
import { Spinner } from "@/components/Spinner";
import { TaskCard } from "@/components/TaskCard";
import { TaskDetailsModal } from "@/components/TaskDetailsModal";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { Project, Task, TaskStatus, UserOption } from "@/lib/types";

export default function TasksPage() {
  const { token, user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]); const [projects, setProjects] = useState<Project[]>([]); const [users, setUsers] = useState<UserOption[]>([]);
  const [status, setStatus] = useState<TaskStatus | "all">("all"); const [period, setPeriod] = useState<"all" | "today" | "overdue">("all"); const [query, setQuery] = useState(""); const [selected, setSelected] = useState<Task | null>(null);
  const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  const load = useCallback(async () => { if (!token || !user) return; setLoading(true); setError(""); try { const [list, p, u] = await Promise.all([api.taskFeed(token, { mine: user.role === "designer" }), api.projects(token), api.userOptions(token, user)]); setTasks(list); setProjects(p); setUsers(u); } catch (e) { setError(e instanceof Error ? e.message : "Не удалось загрузить задачи"); } finally { setLoading(false); } }, [token, user]);
  useEffect(() => { load(); }, [load]);
  const projectMap = useMemo(() => new Map(projects.map((x) => [x.id, x.name])), [projects]); const userMap = useMemo(() => new Map(users.map((x) => [x.id, x.name])), [users]);
  const today = new Date().toISOString().slice(0, 10);
  const filtered = useMemo(() => tasks.filter((task) => (status === "all" || task.status === status) && (period === "all" || (period === "today" ? task.deadline === today && task.status !== "done" : Boolean(task.deadline && task.deadline < today && task.status !== "done"))) && [task.title, task.description || "", projectMap.get(task.project_id) || "", userMap.get(task.assignee_id) || ""].join(" ").toLowerCase().includes(query.toLowerCase())), [period, projectMap, query, status, tasks, today, userMap]);
  function replace(updated: Task) { setTasks((current) => current.map((x) => x.id === updated.id ? updated : x)); setSelected(updated); }
  if (loading) return <div className="page-loading"><Spinner/><span>Загружаем задачи</span></div>;
  return <div className="content-page"><PageHeader eyebrow="ДЕЙСТВИЯ" title="Задачи" subtitle={user?.role === "designer" ? "Ваши конкретные действия по текущим проектам." : "Задачи команды по всем текущим проектам."} actions={<Link href="/projects" className="button button--secondary">Добавить через проект</Link>}/>{error ? <div className="form-error">{error}</div> : null}<div className="toolbar"><label className="search-field"><Icon name="search" size={17}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск по задаче, проекту, исполнителю"/></label><select className="toolbar-select" value={status} onChange={(e) => setStatus(e.target.value as TaskStatus | "all")}><option value="all">Все статусы</option><option value="planned">Запланировано</option><option value="in_progress">В работе</option><option value="review">На проверке</option><option value="done">Готово</option></select><select className="toolbar-select" value={period} onChange={(e) => setPeriod(e.target.value as typeof period)}><option value="all">Все сроки</option><option value="today">Сегодня</option><option value="overdue">Просрочено</option></select></div>{filtered.length ? <div className="task-list">{filtered.map((task) => <TaskCard key={task.id} task={task} projectName={projectMap.get(task.project_id)} assigneeName={userMap.get(task.assignee_id)} onClick={() => setSelected(task)}/>)}</div> : <EmptyState title="Задачи не найдены" text={tasks.length ? "Измените фильтры." : "Задачи появятся после добавления в проектах."}/>} {selected ? <TaskDetailsModal task={selected} projectName={projectMap.get(selected.project_id)} users={users} onClose={() => setSelected(null)} onTaskUpdated={replace}/> : null}</div>;
}
